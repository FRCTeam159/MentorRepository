This is a zip file containing items from Code Quest 2015
put together by Mike Trinka.  The file contains:

- The 2015 problem packet
- My solution code (under the src directory)
- The example inputs and outputs
- The judging inputs and outputs
- Two other partial sets of code

If you have any questions, please feel free to contact me at mike.r.trinka@lmco.com.

-Mike
